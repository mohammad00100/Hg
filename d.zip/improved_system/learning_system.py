from database import DreamDatabase
from nlp_processor import ArabicNLPProcessor, DreamInterpreter
import json
import os
import time
from datetime import datetime

class DreamLearningSystem:
    """
    نظام التعلم الذاتي لتفسير الأحلام
    يجمع بين قاعدة البيانات ومعالج اللغة الطبيعية ومفسر الأحلام
    """
    
    def __init__(self, db_path='dreams.db', csv_path=None, models_dir='models'):
        """
        تهيئة نظام التعلم الذاتي
        
        المعلمات:
            db_path (str): مسار ملف قاعدة البيانات
            csv_path (str): مسار ملف CSV الأصلي (اختياري)
            models_dir (str): مجلد حفظ النماذج
        """
        # إنشاء مجلد النماذج إذا لم يكن موجودًا
        if not os.path.exists(models_dir):
            os.makedirs(models_dir)
        
        self.models_dir = models_dir
        
        # تهيئة مدير قاعدة البيانات
        self.db_manager = DreamDatabase(db_path, csv_path)
        
        # تهيئة معالج اللغة الطبيعية
        nlp_model_path = os.path.join(models_dir, 'nlp_model.pkl')
        if os.path.exists(nlp_model_path):
            self.nlp_processor = ArabicNLPProcessor(nlp_model_path)
        else:
            self.nlp_processor = ArabicNLPProcessor()
        
        # تهيئة مفسر الأحلام
        self.dream_interpreter = DreamInterpreter(self.db_manager, self.nlp_processor)
        
        # تحميل نموذج LSTM إذا كان موجودًا
        lstm_model_path = os.path.join(models_dir, 'lstm_model')
        if os.path.exists(lstm_model_path):
            try:
                self.dream_interpreter.load_model(lstm_model_path)
                print("تم تحميل نموذج LSTM بنجاح")
            except Exception as e:
                print(f"خطأ أثناء تحميل نموذج LSTM: {e}")
        
        # سجل التعلم
        self.learning_log = []
        
        # تحميل سجل التعلم إذا كان موجودًا
        log_path = os.path.join(models_dir, 'learning_log.json')
        if os.path.exists(log_path):
            try:
                with open(log_path, 'r', encoding='utf-8') as f:
                    self.learning_log = json.load(f)
            except Exception as e:
                print(f"خطأ أثناء تحميل سجل التعلم: {e}")
    
    def interpret_dream(self, query, session_id=None):
        """
        تفسير الحلم
        
        المعلمات:
            query (str): استعلام المستخدم
            session_id (str): معرف الجلسة (اختياري)
            
        العائد:
            dict: التفسير مع معلومات إضافية
        """
        # تفسير الحلم باستخدام مفسر الأحلام
        interpretation = self.dream_interpreter.interpret_dream(query, session_id)
        
        # إضافة معلومات إضافية
        interpretation['timestamp'] = datetime.now().isoformat()
        interpretation['session_id'] = session_id
        
        return interpretation
    
    def save_feedback(self, query_id, rating, notes=None):
        """
        حفظ تقييم المستخدم
        
        المعلمات:
            query_id (int): معرف الاستعلام
            rating (int): التقييم (1-5)
            notes (str): ملاحظات المستخدم (اختياري)
        """
        # حفظ التقييم في قاعدة البيانات
        self.db_manager.save_feedback(query_id, rating, notes)
        
        # إضافة التقييم إلى سجل التعلم
        self.learning_log.append({
            'query_id': query_id,
            'rating': rating,
            'notes': notes,
            'timestamp': datetime.now().isoformat()
        })
        
        # حفظ سجل التعلم
        self._save_learning_log()
        
        # تحقق مما إذا كان يجب إعادة تدريب النماذج
        if len(self.learning_log) % 10 == 0:  # إعادة التدريب كل 10 تقييمات
            self.train_models()
    
    def train_models(self):
        """
        تدريب نماذج التعلم الآلي
        """
        print("بدء تدريب النماذج...")
        
        # الحصول على بيانات التدريب
        learning_data = self.db_manager.get_learning_data()
        
        if not learning_data or len(learning_data) < 10:
            print("لا توجد بيانات كافية للتدريب")
            return
        
        # تدريب نموذج التجميع
        print("تدريب نموذج التجميع...")
        queries = [data['query'] for data in learning_data]
        self.nlp_processor.train_clustering_model(queries)
        
        # حفظ نموذج NLP
        nlp_model_path = os.path.join(self.models_dir, 'nlp_model.pkl')
        self.nlp_processor.save_model(nlp_model_path)
        
        # تدريب نموذج LSTM إذا كان هناك بيانات كافية
        if len(learning_data) >= 50:
            print("تدريب نموذج LSTM...")
            
            # إعداد نموذج LSTM إذا لم يكن موجودًا
            if not self.dream_interpreter.lstm_model:
                # بناء قاموس الكلمات
                all_text = ' '.join([data['query'] + ' ' + data['response'] for data in learning_data])
                tokens = self.nlp_processor.tokenize_arabic(all_text)
                vocab_size = len(set(tokens)) + 1
                
                # بناء النموذج
                self.dream_interpreter.build_lstm_model(vocab_size)
            
            # تدريب النموذج
            history = self.dream_interpreter.train_lstm_model(epochs=5)
            
            # حفظ النموذج
            lstm_model_path = os.path.join(self.models_dir, 'lstm_model')
            self.dream_interpreter.save_model(lstm_model_path)
            
            # تحديث سجل التعلم
            self.learning_log.append({
                'event': 'model_training',
                'model': 'lstm',
                'timestamp': datetime.now().isoformat()
            })
            
            # حفظ سجل التعلم
            self._save_learning_log()
        
        print("اكتمل تدريب النماذج")
    
    def _save_learning_log(self):
        """
        حفظ سجل التعلم
        """
        log_path = os.path.join(self.models_dir, 'learning_log.json')
        try:
            with open(log_path, 'w', encoding='utf-8') as f:
                json.dump(self.learning_log, f, ensure_ascii=False, indent=2)
        except Exception as e:
            print(f"خطأ أثناء حفظ سجل التعلم: {e}")
    
    def get_learning_stats(self):
        """
        الحصول على إحصائيات التعلم
        
        العائد:
            dict: إحصائيات التعلم
        """
        # عدد الاستعلامات
        query_count = len(self.learning_log)
        
        # متوسط التقييمات
        ratings = [log['rating'] for log in self.learning_log if 'rating' in log]
        avg_rating = sum(ratings) / len(ratings) if ratings else 0
        
        # عدد مرات التدريب
        training_count = sum(1 for log in self.learning_log if log.get('event') == 'model_training')
        
        # الحصول على إحصائيات التعلم من قاعدة البيانات
        lstm_accuracy = self.db_manager.get_learning_stats('lstm_accuracy')
        
        return {
            'query_count': query_count,
            'avg_rating': avg_rating,
            'training_count': training_count,
            'lstm_accuracy': lstm_accuracy
        }
