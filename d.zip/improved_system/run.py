#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
نظام تفسير الأحلام الذكي - نقطة الدخول الرئيسية
"""

import os
import sys
import logging
from datetime import datetime

# إعداد التسجيل
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("app.log"),
        logging.StreamHandler(sys.stdout)
    ]
)

logger = logging.getLogger(__name__)

# التأكد من وجود المجلدات اللازمة
def ensure_directories():
    """التأكد من وجود جميع المجلدات اللازمة للتطبيق"""
    directories = [
        'data',
        'data/backups',
        'models',
        'static/css',
        'static/js',
        'templates'
    ]
    
    for directory in directories:
        os.makedirs(directory, exist_ok=True)
        logger.info(f"تم التأكد من وجود المجلد: {directory}")

# تهيئة النظام
def initialize_system():
    """تهيئة النظام وإعداد المكونات الأساسية"""
    from database import DreamDatabase
    from nlp_processor import ArabicNLPProcessor
    from learning_system import DreamLearningSystem
    
    # مسارات الملفات
    base_dir = os.path.dirname(os.path.abspath(__file__))
    csv_path = os.path.join(base_dir, 'data', 'dream.csv')
    db_path = os.path.join(base_dir, 'data', 'dreams.db')
    models_dir = os.path.join(base_dir, 'models')
    
    # إنشاء نسخة احتياطية من قاعدة البيانات إذا كانت موجودة
    if os.path.exists(db_path):
        backup_time = datetime.now().strftime('%Y%m%d_%H%M%S')
        backup_path = os.path.join(base_dir, 'data', 'backups', f'dreams_{backup_time}.db')
        try:
            import shutil
            shutil.copy2(db_path, backup_path)
            logger.info(f"تم إنشاء نسخة احتياطية من قاعدة البيانات: {backup_path}")
        except Exception as e:
            logger.warning(f"فشل إنشاء نسخة احتياطية: {e}")
    
    # تهيئة نظام التعلم
    dream_system = DreamLearningSystem(db_path, csv_path, models_dir)
    logger.info("تم تهيئة نظام التعلم بنجاح")
    
    return dream_system

# تشغيل التطبيق
if __name__ == "__main__":
    try:
        # التأكد من وجود المجلدات
        ensure_directories()
        
        # تهيئة النظام
        dream_system = initialize_system()
        
        # تشغيل خادم Flask
        from app import app
        app.run(host='0.0.0.0', port=5000, debug=True)
    except Exception as e:
        logger.error(f"حدث خطأ أثناء تشغيل التطبيق: {e}", exc_info=True)
