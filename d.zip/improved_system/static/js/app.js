$(document).ready(function() {
    // متغيرات النظام
    let isProcessing = false;
    let lastRequest = null;
    let sessionId = generateSessionId();
    let currentQueryId = null;

    // تهيئة واجهة المستخدم
    initUI();

    // إضافة أحداث للعناصر
    setupEventListeners();

    // تهيئة واجهة المستخدم
    function initUI() {
        // التركيز على حقل الإدخال
        $('#userInput').focus();
        
        // تحميل الرسائل المحفوظة
        loadSavedMessages();
        
        // تحميل الإحصائيات
        loadStats();
    }

    // إعداد أحداث العناصر
    function setupEventListeners() {
        // إرسال الرسالة عند النقر على زر الإرسال
        $('#sendButton').click(function() {
            sendQuery();
        });

        // إرسال الرسالة عند الضغط على Enter
        $('#userInput').keypress(function(e) {
            if (e.which === 13) {
                sendQuery();
                return false;
            }
        });

        // استخدام أمثلة الأحلام
        $('.example-card').click(function() {
            const dreamText = $(this).data('dream');
            $('#userInput').val(dreamText).focus();
        });

        // عرض/إخفاء النافذة المعلوماتية
        $('#infoBtn').click(function() {
            $('#infoModal').fadeIn();
        });

        // عرض/إخفاء نافذة الإحصائيات
        $('#statsBtn').click(function() {
            loadStats();
            $('#statsModal').fadeIn();
        });

        // إغلاق النوافذ المنبثقة
        $('.close-modal').click(function() {
            $(this).closest('.info-modal, .stats-modal, .feedback-modal').fadeOut();
        });

        // عند النقر خارج النافذة
        $(window).click(function(e) {
            if ($(e.target).is('.info-modal, .stats-modal, .feedback-modal')) {
                $('.info-modal, .stats-modal, .feedback-modal').fadeOut();
            }
        });

        // تقييم النجوم
        $(document).on('click', '.rating-stars span', function() {
            const rating = $(this).data('rating');
            $('.rating-stars span').removeClass('active');
            $(this).addClass('active').prevAll().addClass('active');
            $('#submitFeedback').data('rating', rating);
        });

        // إرسال التقييم
        $(document).on('click', '#submitFeedback', function() {
            const rating = $(this).data('rating') || 0;
            const notes = $('#feedbackNotes').val();
            
            if (rating > 0 && currentQueryId) {
                submitFeedback(currentQueryId, rating, notes);
                $('#feedbackModal').fadeOut();
            } else {
                showToast('الرجاء اختيار تقييم');
            }
        });

        // تدريب النموذج
        $('#trainButton').click(function() {
            trainModel();
        });

        // التعرف على الصوت
        $('#voiceBtn').click(function() {
            startSpeechRecognition();
        });
    }

    // تحميل الرسائل المحفوظة
    function loadSavedMessages() {
        const savedMessages = localStorage.getItem('dreamChatMessages');
        if (savedMessages) {
            $('#chatMessages').html(savedMessages);
            scrollToBottom();
        }
    }

    // حفظ الرسائل
    function saveMessages() {
        localStorage.setItem('dreamChatMessages', $('#chatMessages').html());
    }

    // إرسال الاستعلام
    function sendQuery() {
        const userInput = $('#userInput').val().trim();
        
        if (userInput !== '' && !isProcessing) {
            isProcessing = true;
            $('#sendButton').prop('disabled', true);
            
            addUserMessage(userInput);
            showProcessingIndicator();
            
            if (lastRequest) {
                lastRequest.abort();
            }
            
            lastRequest = $.ajax({
                url: '/api/interpret',
                type: 'POST',
                contentType: 'application/json',
                data: JSON.stringify({
                    dream: userInput,
                    session_id: sessionId
                }),
                success: function(response) {
                    handleSuccessResponse(response, userInput);
                },
                error: function(xhr, status, error) {
                    handleErrorResponse(error);
                },
                complete: function() {
                    isProcessing = false;
                    $('#sendButton').prop('disabled', false);
                    lastRequest = null;
                }
            });
            
            $('#userInput').val('');
        }
    }

    // إضافة رسالة المستخدم
    function addUserMessage(message) {
        const timeString = getCurrentTimeString();
        
        const userMessageHTML = `
            <div class="message user-message">
                <div class="message-content">${escapeHtml(message)}</div>
                <div class="message-time">${timeString}</div>
            </div>
        `;
        
        $('#chatMessages').append(userMessageHTML);
        scrollToBottom();
        saveMessages();
    }

    // إظهار مؤشر المعالجة
    function showProcessingIndicator() {
        const processingHTML = `
            <div class="message ai-message processing-message">
                <div class="message-content">
                    <span class="typing-indicator">
                        <span></span>
                        <span></span>
                        <span></span>
                    </span>
                    جارٍ تحليل حلمك وتفسيره...
                </div>
            </div>
        `;
        
        $('#chatMessages').append(processingHTML);
        scrollToBottom();
    }

    // معالجة الرد الناجح
    function handleSuccessResponse(response, userQuery) {
        $('.processing-message').remove();
        
        const timeString = getCurrentTimeString();
        currentQueryId = response.query_id;
        
        const aiMessageHTML = `
            <div class="message ai-message">
                <div class="message-content">${response.response}</div>
                <div class="message-time">${timeString}</div>
                <div class="interpretation-actions">
                    <button class="copy-btn" data-text="${escapeHtml(response.response)}">نسخ التفسير</button>
                    <button class="save-btn" data-dream="${escapeHtml(userQuery)}">حفظ التفسير</button>
                    <button class="feedback-btn" data-query-id="${response.query_id}">تقييم التفسير</button>
                </div>
            </div>
        `;
        
        $('#chatMessages').append(aiMessageHTML);
        scrollToBottom();
        saveMessages();
        
        // إضافة أحداث للأزرار
        $('.copy-btn').off('click').on('click', function() {
            const textToCopy = $(this).data('text');
            copyToClipboard(textToCopy);
            showToast('تم نسخ التفسير إلى الحافظة');
        });
        
        $('.save-btn').off('click').on('click', function() {
            const dream = $(this).data('dream');
            const interpretation = $(this).closest('.message').find('.message-content').html();
            saveInterpretation(dream, interpretation);
        });
        
        $('.feedback-btn').off('click').on('click', function() {
            currentQueryId = $(this).data('query-id');
            showFeedbackModal();
        });
    }

    // معالجة الخطأ
    function handleErrorResponse(error) {
        $('.processing-message').remove();
        
        const timeString = getCurrentTimeString();
        
        const errorMessage = `
            <div class="message ai-message error-message">
                <div class="message-content">
                    حدث خطأ أثناء معالجة طلبك. يرجى المحاولة مرة أخرى.
                    ${error ? `<br><small>${escapeHtml(error)}</small>` : ''}
                </div>
                <div class="message-time">${timeString}</div>
            </div>
        `;
        
        $('#chatMessages').append(errorMessage);
        scrollToBottom();
        saveMessages();
    }

    // نسخ النص إلى الحافظة
    function copyToClipboard(text) {
        const textarea = document.createElement('textarea');
        textarea.value = text;
        document.body.appendChild(textarea);
        textarea.select();
        document.execCommand('copy');
        document.body.removeChild(textarea);
    }

    // عرض رسالة toast
    function showToast(message) {
        $('.toast').remove();
        const toast = $(`<div class="toast">${message}</div>`);
        $('body').append(toast);
        setTimeout(() => toast.remove(), 3000);
    }

    // حفظ التفسير المفضل
    function saveInterpretation(dream, interpretation) {
        const savedInterpretations = JSON.parse(localStorage.getItem('savedInterpretations') || '[]');
        
        if (!savedInterpretations.some(item => item.dream === dream)) {
            savedInterpretations.push({
                dream: dream,
                interpretation: interpretation,
                date: new Date().toISOString()
            });
            
            localStorage.setItem('savedInterpretations', JSON.stringify(savedInterpretations));
            showToast('تم حفظ التفسير بنجاح');
        } else {
            showToast('هذا التفسير محفوظ مسبقاً');
        }
    }

    // عرض نموذج التقييم
    function showFeedbackModal() {
        // إعادة تعيين النموذج
        $('.rating-stars span').removeClass('active');
        $('#feedbackNotes').val('');
        
        // عرض النموذج
        $('#feedbackModal').fadeIn();
    }

    // إرسال التقييم
    function submitFeedback(queryId, rating, notes) {
        $.ajax({
            url: '/api/feedback',
            type: 'POST',
            contentType: 'application/json',
            data: JSON.stringify({
                query_id: queryId,
                rating: rating,
                notes: notes
            }),
            success: function() {
                showToast('شكراً لتقييمك!');
                loadStats();
            },
            error: function() {
                showToast('حدث خطأ أثناء إرسال التقييم');
            }
        });
    }

    // تحميل الإحصائيات
    function loadStats() {
        $.ajax({
            url: '/api/stats',
            type: 'GET',
            success: function(stats) {
                $('#queryCount').text(stats.query_count || 0);
                $('#avgRating').text((stats.avg_rating || 0).toFixed(1));
                $('#trainingCount').text(stats.training_count || 0);
                
                const accuracy = stats.lstm_accuracy && stats.lstm_accuracy.length > 0 
                    ? (stats.lstm_accuracy[0].value * 100).toFixed(1) 
                    : 0;
                $('#accuracy').text(accuracy + '%');
            }
        });
    }

    // تدريب النموذج
    function trainModel() {
        $('#trainButton').prop('disabled', true).text('جاري التدريب...');
        
        $.ajax({
            url: '/api/train',
            type: 'POST',
            success: function() {
                showToast('تم تدريب النموذج بنجاح');
                loadStats();
            },
            error: function() {
                showToast('حدث خطأ أثناء تدريب النموذج');
            },
            complete: function() {
                $('#trainButton').prop('disabled', false).text('تدريب النموذج');
            }
        });
    }

    // التعرف على الصوت
    function startSpeechRecognition() {
        if ('webkitSpeechRecognition' in window) {
            const recognition = new webkitSpeechRecognition();
            recognition.lang = 'ar-SA';
            recognition.continuous = false;
            recognition.interimResults = false;
            
            recognition.onstart = function() {
                $('#voiceBtn').html('<i class="fas fa-spinner fa-spin"></i>');
                showToast('يرجى التحدث الآن...');
            };
            
            recognition.onresult = function(event) {
                const transcript = event.results[0][0].transcript;
                $('#userInput').val(transcript);
            };
            
            recognition.onerror = function() {
                showToast('حدث خطأ في التعرف على الصوت');
            };
            
            recognition.onend = function() {
                $('#voiceBtn').html('<i class="fas fa-microphone"></i>');
            };
            
            recognition.start();
        } else {
            showToast('متصفحك لا يدعم التعرف على الصوت');
        }
    }

    // التمرير إلى أسفل
    function scrollToBottom() {
        const chatMessages = document.getElementById('chatMessages');
        chatMessages.scrollTop = chatMessages.scrollHeight;
    }

    // الحصول على الوقت الحالي كسلسلة
    function getCurrentTimeString() {
        const now = new Date();
        const hours = now.getHours().toString().padStart(2, '0');
        const minutes = now.getMinutes().toString().padStart(2, '0');
        return `${hours}:${minutes}`;
    }

    // إنشاء معرف جلسة
    function generateSessionId() {
        return 'session_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9);
    }

    // تهروب HTML
    function escapeHtml(text) {
        return text
            .replace(/&/g, "&amp;")
            .replace(/</g, "&lt;")
            .replace(/>/g, "&gt;")
            .replace(/"/g, "&quot;")
            .replace(/'/g, "&#039;");
    }
});
