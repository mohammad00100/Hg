import re
import pickle
import numpy as np
from collections import Counter
import nltk
from nltk.tokenize import word_tokenize
from nltk.corpus import stopwords
import tensorflow as tf
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
from sklearn.cluster import KMeans

# تنزيل الموارد اللازمة من NLTK
try:
    nltk.data.find('tokenizers/punkt')
except LookupError:
    nltk.download('punkt')

try:
    nltk.data.find('corpora/stopwords')
except LookupError:
    nltk.download('stopwords')

class ArabicNLPProcessor:
    """
    معالج اللغة العربية الطبيعية لتحليل وفهم نصوص الأحلام
    """
    
    def __init__(self, model_path=None):
        """
        تهيئة معالج اللغة الطبيعية
        
        المعلمات:
            model_path (str): مسار نموذج التعلم الآلي المحفوظ (اختياري)
        """
        # قائمة الكلمات المتوقفة بالعربية
        self.arabic_stopwords = set(stopwords.words('arabic'))
        
        # إضافة كلمات متوقفة خاصة بالأحلام
        dream_specific_stopwords = {
            'رأيت', 'حلمت', 'المنام', 'نومي', 'أنني', 'كأنني', 'كأني',
            'أني', 'وكأن', 'وكأني', 'وكأنني', 'رؤيا', 'حلم'
        }
        self.arabic_stopwords.update(dream_specific_stopwords)
        
        # نموذج TF-IDF للتحليل النصي
        self.tfidf_vectorizer = TfidfVectorizer(
            tokenizer=self.tokenize_arabic,
            stop_words=list(self.arabic_stopwords),
            ngram_range=(1, 2),
            max_features=5000
        )
        
        # نموذج التجميع لتصنيف الأحلام
        self.kmeans = None
        
        # تحميل النموذج إذا كان متاحًا
        if model_path:
            self.load_model(model_path)
    
    def tokenize_arabic(self, text):
        """
        تقسيم النص العربي إلى كلمات
        
        المعلمات:
            text (str): النص المراد تقسيمه
            
        العائد:
            list: قائمة الكلمات
        """
        # تنظيف النص
        text = self.clean_text(text)
        
        # تقسيم النص إلى كلمات بطريقة بسيطة لتجنب مشاكل NLTK
        tokens = text.split()
        
        # إزالة الكلمات المتوقفة والكلمات القصيرة
        tokens = [token for token in tokens if token not in self.arabic_stopwords and len(token) > 1]
        
        return tokens
    
    def clean_text(self, text):
        """
        تنظيف النص من الأحرف الخاصة والأرقام
        
        المعلمات:
            text (str): النص المراد تنظيفه
            
        العائد:
            str: النص بعد التنظيف
        """
        # إزالة التشكيل
        text = re.sub(r'[\u064B-\u065F\u0670]', '', text)
        
        # استبدال الأحرف الخاصة بمسافات
        text = re.sub(r'[^\u0600-\u06FF\s]', ' ', text)
        
        # استبدال المسافات المتعددة بمسافة واحدة
        text = re.sub(r'\s+', ' ', text)
        
        return text.strip()
    
    def extract_keywords(self, text, top_n=10):
        """
        استخراج الكلمات المفتاحية من النص
        
        المعلمات:
            text (str): النص المراد تحليله
            top_n (int): عدد الكلمات المفتاحية المراد استخراجها
            
        العائد:
            list: قائمة الكلمات المفتاحية مع أوزانها
        """
        # تقسيم النص إلى كلمات
        tokens = self.tokenize_arabic(text)
        
        # حساب تكرار الكلمات
        word_freq = Counter(tokens)
        
        # استخراج الكلمات الأكثر تكرارًا
        keywords = word_freq.most_common(top_n)
        
        return keywords
    
    def calculate_similarity(self, text1, text2):
        """
        حساب التشابه بين نصين
        
        المعلمات:
            text1 (str): النص الأول
            text2 (str): النص الثاني
            
        العائد:
            float: درجة التشابه (0-1)
        """
        # تحويل النصوص إلى متجهات TF-IDF
        tfidf_matrix = self.tfidf_vectorizer.fit_transform([text1, text2])
        
        # حساب التشابه باستخدام جيب التمام
        similarity = cosine_similarity(tfidf_matrix[0:1], tfidf_matrix[1:2])[0][0]
        
        return similarity
    
    def train_clustering_model(self, texts, n_clusters=10):
        """
        تدريب نموذج التجميع لتصنيف الأحلام
        
        المعلمات:
            texts (list): قائمة النصوص للتدريب
            n_clusters (int): عدد المجموعات
        """
        # تحويل النصوص إلى متجهات TF-IDF
        tfidf_matrix = self.tfidf_vectorizer.fit_transform(texts)
        
        # تدريب نموذج K-means
        self.kmeans = KMeans(n_clusters=n_clusters, random_state=42)
        self.kmeans.fit(tfidf_matrix)
    
    def predict_cluster(self, text):
        """
        التنبؤ بمجموعة النص
        
        المعلمات:
            text (str): النص المراد تصنيفه
            
        العائد:
            int: رقم المجموعة
        """
        if not self.kmeans:
            raise ValueError("يجب تدريب نموذج التجميع أولاً")
        
        # تحويل النص إلى متجه TF-IDF
        tfidf_vector = self.tfidf_vectorizer.transform([text])
        
        # التنبؤ بالمجموعة
        cluster = self.kmeans.predict(tfidf_vector)[0]
        
        return cluster
    
    def save_model(self, path):
        """
        حفظ النموذج إلى ملف
        
        المعلمات:
            path (str): مسار الملف
        """
        model_data = {
            'tfidf_vectorizer': self.tfidf_vectorizer,
            'kmeans': self.kmeans
        }
        
        with open(path, 'wb') as f:
            pickle.dump(model_data, f)
    
    def load_model(self, path):
        """
        تحميل النموذج من ملف
        
        المعلمات:
            path (str): مسار الملف
        """
        try:
            with open(path, 'rb') as f:
                model_data = pickle.load(f)
                
            self.tfidf_vectorizer = model_data['tfidf_vectorizer']
            self.kmeans = model_data['kmeans']
        except Exception as e:
            print(f"خطأ أثناء تحميل النموذج: {e}")


class DreamInterpreter:
    """
    مفسر الأحلام باستخدام التعلم الآلي
    """
    
    def __init__(self, db_manager, nlp_processor):
        """
        تهيئة مفسر الأحلام
        
        المعلمات:
            db_manager: مدير قاعدة البيانات
            nlp_processor: معالج اللغة الطبيعية
        """
        self.db_manager = db_manager
        self.nlp_processor = nlp_processor
        
        # نموذج LSTM للتعلم العميق
        self.lstm_model = None
        
        # قاموس الكلمات
        self.word_index = {}
        
        # الحد الأقصى لطول النص
        self.max_sequence_length = 100
    
    def preprocess_query(self, query):
        """
        معالجة استعلام المستخدم
        
        المعلمات:
            query (str): استعلام المستخدم
            
        العائد:
            str: الاستعلام بعد المعالجة
        """
        # تنظيف النص
        clean_query = self.nlp_processor.clean_text(query)
        
        # استخراج الكلمات المفتاحية
        keywords = self.nlp_processor.extract_keywords(clean_query)
        
        # إعادة بناء الاستعلام باستخدام الكلمات المفتاحية فقط
        processed_query = ' '.join([word for word, _ in keywords])
        
        return processed_query
    
    def interpret_dream(self, query, session_id=None):
        """
        تفسير الحلم
        
        المعلمات:
            query (str): استعلام المستخدم
            session_id (str): معرف الجلسة (اختياري)
            
        العائد:
            dict: التفسير مع معلومات إضافية
        """
        # معالجة الاستعلام
        processed_query = self.preprocess_query(query)
        
        # البحث عن تفسيرات مشابهة
        interpretations = self.db_manager.search_interpretations(processed_query)
        
        # إذا لم يتم العثور على تفسيرات، استخدم النموذج العميق إذا كان متاحًا
        if not interpretations and self.lstm_model:
            generated_interpretation = self.generate_interpretation(query)
            if generated_interpretation:
                interpretations = [{
                    'id': 0,
                    'interpreter': 'النموذج الذكي',
                    'term': processed_query,
                    'interpretation': generated_interpretation,
                    'relevance': 0.7
                }]
        
        # إذا لم يتم العثور على تفسيرات، أعد رسالة اعتذار
        if not interpretations:
            response = "عذراً، لم أتمكن من العثور على تفسير مناسب لحلمك. يرجى توفير المزيد من التفاصيل أو تجربة حلم آخر."
        else:
            # دمج التفسيرات المتعددة إذا وجدت
            if len(interpretations) > 1:
                # ترتيب التفسيرات حسب الصلة
                interpretations.sort(key=lambda x: x['relevance'], reverse=True)
                
                # إنشاء تفسير مدمج
                combined_interpretation = f"وفقاً لـ {interpretations[0]['interpreter']}:\n{interpretations[0]['interpretation']}\n\n"
                
                # إضافة تفسيرات إضافية
                for interp in interpretations[1:]:
                    combined_interpretation += f"وأيضاً وفقاً لـ {interp['interpreter']}:\n{interp['interpretation']}\n\n"
                
                response = combined_interpretation
            else:
                # استخدام التفسير الوحيد
                response = f"وفقاً لـ {interpretations[0]['interpreter']}:\n{interpretations[0]['interpretation']}"
        
        # حفظ الاستعلام والاستجابة
        query_id = self.db_manager.save_user_query(query, response, session_id)
        
        return {
            'query_id': query_id,
            'response': response,
            'interpretations': interpretations
        }
    
    def build_lstm_model(self, vocab_size, embedding_dim=100, lstm_units=128):
        """
        بناء نموذج LSTM للتعلم العميق
        
        المعلمات:
            vocab_size (int): حجم المفردات
            embedding_dim (int): أبعاد التضمين
            lstm_units (int): عدد وحدات LSTM
        """
        model = tf.keras.Sequential([
            tf.keras.layers.Embedding(vocab_size, embedding_dim, mask_zero=True),
            tf.keras.layers.Bidirectional(tf.keras.layers.LSTM(lstm_units, return_sequences=True)),
            tf.keras.layers.Bidirectional(tf.keras.layers.LSTM(lstm_units)),
            tf.keras.layers.Dense(lstm_units, activation='relu'),
            tf.keras.layers.Dropout(0.5),
            tf.keras.layers.Dense(vocab_size)
        ])
        
        model.compile(
            optimizer='adam',
            loss=tf.keras.losses.SparseCategoricalCrossentropy(from_logits=True),
            metrics=['accuracy']
        )
        
        self.lstm_model = model
    
    def train_lstm_model(self, epochs=10, batch_size=64):
        """
        تدريب نموذج LSTM
        
        المعلمات:
            epochs (int): عدد الدورات
            batch_size (int): حجم الدفعة
        """
        if not self.lstm_model:
            raise ValueError("يجب بناء النموذج أولاً")
        
        # الحصول على بيانات التدريب
        learning_data = self.db_manager.get_learning_data()
        
        if not learning_data:
            print("لا توجد بيانات كافية للتدريب")
            return
        
        # إعداد البيانات للتدريب
        queries = [data['query'] for data in learning_data]
        responses = [data['response'] for data in learning_data]
        
        # بناء قاموس الكلمات
        all_text = ' '.join(queries + responses)
        tokens = self.nlp_processor.tokenize_arabic(all_text)
        word_counts = Counter(tokens)
        
        # ترتيب الكلمات حسب التكرار
        sorted_vocab = sorted(word_counts.items(), key=lambda x: x[1], reverse=True)
        
        # إنشاء قاموس الكلمات
        self.word_index = {word: i+1 for i, (word, _) in enumerate(sorted_vocab)}
        
        # تحويل النصوص إلى تسلسلات رقمية
        query_sequences = self._texts_to_sequences(queries)
        response_sequences = self._texts_to_sequences(responses)
        
        # تبطين التسلسلات
        padded_queries = tf.keras.preprocessing.sequence.pad_sequences(
            query_sequences, maxlen=self.max_sequence_length, padding='post'
        )
        
        padded_responses = tf.keras.preprocessing.sequence.pad_sequences(
            response_sequences, maxlen=self.max_sequence_length, padding='post'
        )
        
        # تدريب النموذج
        history = self.lstm_model.fit(
            padded_queries, padded_responses,
            epochs=epochs,
            batch_size=batch_size,
            validation_split=0.2
        )
        
        # تحديث إحصائيات التعلم
        final_accuracy = history.history['accuracy'][-1]
        self.db_manager.update_learning_stats('lstm_accuracy', final_accuracy)
        
        return history
    
    def _texts_to_sequences(self, texts):
        """
        تحويل النصوص إلى تسلسلات رقمية
        
        المعلمات:
            texts (list): قائمة النصوص
            
        العائد:
            list: قائمة التسلسلات الرقمية
        """
        sequences = []
        
        for text in texts:
            tokens = self.nlp_processor.tokenize_arabic(text)
            sequence = [self.word_index.get(token, 0) for token in tokens]
            sequences.append(sequence)
        
        return sequences
    
    def generate_interpretation(self, query):
        """
        توليد تفسير باستخدام نموذج LSTM
        
        المعلمات:
            query (str): استعلام المستخدم
            
        العائد:
            str: التفسير المولد
        """
        if not self.lstm_model:
            return None
        
        # تحويل الاستعلام إلى تسلسل رقمي
        tokens = self.nlp_processor.tokenize_arabic(query)
        sequence = [self.word_index.get(token, 0) for token in tokens]
        
        # تبطين التسلسل
        padded_sequence = tf.keras.preprocessing.sequence.pad_sequences(
            [sequence], maxlen=self.max_sequence_length, padding='post'
        )
        
        # التنبؤ بالتفسير
        predictions = self.lstm_model.predict(padded_sequence)[0]
        
        # تحويل التنبؤات إلى كلمات
        reverse_word_index = {i: word for word, i in self.word_index.items()}
        
        # اختيار أفضل 50 كلمة
        top_indices = np.argsort(predictions)[-50:]
        
        # بناء التفسير
        interpretation_tokens = [reverse_word_index.get(i, '') for i in top_indices if i > 0]
        interpretation = ' '.join(interpretation_tokens)
        
        return interpretation
    
    def save_model(self, path):
        """
        حفظ النموذج إلى ملف
        
        المعلمات:
            path (str): مسار الملف
        """
        if not self.lstm_model:
            raise ValueError("لا يوجد نموذج للحفظ")
        
        # حفظ النموذج
        self.lstm_model.save(path)
        
        # حفظ قاموس الكلمات
        with open(f"{path}_word_index.pkl", 'wb') as f:
            pickle.dump(self.word_index, f)
    
    def load_model(self, path):
        """
        تحميل النموذج من ملف
        
        المعلمات:
            path (str): مسار الملف
        """
        try:
            # تحميل النموذج
            self.lstm_model = tf.keras.models.load_model(path)
            
            # تحميل قاموس الكلمات
            with open(f"{path}_word_index.pkl", 'rb') as f:
                self.word_index = pickle.load(f)
        except Exception as e:
            print(f"خطأ أثناء تحميل النموذج: {e}")
