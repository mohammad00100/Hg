import os
import sys
import unittest
import tempfile
import shutil
import json
from database import DreamDatabase
from nlp_processor import ArabicNLPProcessor, DreamInterpreter
from learning_system import DreamLearningSystem

class TestDreamSystem(unittest.TestCase):
    """
    اختبارات وحدة لنظام تفسير الأحلام المحسن
    """
    
    def setUp(self):
        """إعداد بيئة الاختبار"""
        # إنشاء مجلد مؤقت للاختبارات
        self.test_dir = tempfile.mkdtemp()
        
        # مسار ملف CSV الأصلي
        self.csv_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data', 'dream.csv')
        
        # مسار قاعدة البيانات للاختبار
        self.db_path = os.path.join(self.test_dir, 'test_dreams.db')
        
        # مسار مجلد النماذج للاختبار
        self.models_dir = os.path.join(self.test_dir, 'models')
        os.makedirs(self.models_dir, exist_ok=True)
        
        # تهيئة مكونات النظام للاختبار
        self.db_manager = DreamDatabase(self.db_path, self.csv_path)
        self.nlp_processor = ArabicNLPProcessor()
        self.dream_interpreter = DreamInterpreter(self.db_manager, self.nlp_processor)
        self.learning_system = DreamLearningSystem(self.db_path, self.csv_path, self.models_dir)
    
    def tearDown(self):
        """تنظيف بيئة الاختبار"""
        # حذف المجلد المؤقت
        shutil.rmtree(self.test_dir)
    
    def test_database_initialization(self):
        """اختبار تهيئة قاعدة البيانات"""
        # التحقق من إنشاء قاعدة البيانات
        self.assertTrue(os.path.exists(self.db_path), "لم يتم إنشاء ملف قاعدة البيانات")
        
        # التحقق من استيراد البيانات من CSV
        self.db_manager.connect()
        self.db_manager.cursor.execute("SELECT COUNT(*) FROM interpretations")
        count = self.db_manager.cursor.fetchone()[0]
        self.db_manager.disconnect()
        
        self.assertGreater(count, 0, "لم يتم استيراد البيانات من CSV")
        print(f"تم استيراد {count} سجل من CSV")
    
    def test_nlp_processing(self):
        """اختبار معالجة اللغة الطبيعية"""
        # اختبار تنظيف النص
        text = "رأيت في المنام أنني أطير في السماء العالية فوق الغيوم!"
        clean_text = self.nlp_processor.clean_text(text)
        self.assertIn("أطير", clean_text, "فشل تنظيف النص")
        
        # اختبار استخراج الكلمات المفتاحية
        keywords = self.nlp_processor.extract_keywords(text)
        self.assertGreater(len(keywords), 0, "فشل استخراج الكلمات المفتاحية")
        print(f"الكلمات المفتاحية: {keywords}")
        
        # اختبار حساب التشابه
        text1 = "رأيت في المنام أنني أطير في السماء"
        text2 = "حلمت بأنني أطير عالياً فوق الغيوم"
        similarity = self.nlp_processor.calculate_similarity(text1, text2)
        self.assertGreater(similarity, 0, "فشل حساب التشابه")
        print(f"درجة التشابه: {similarity}")
    
    def test_dream_interpretation(self):
        """اختبار تفسير الأحلام"""
        # اختبار تفسير حلم
        query = "رأيت في المنام أنني أطير في السماء"
        interpretation = self.dream_interpreter.interpret_dream(query)
        
        self.assertIsNotNone(interpretation, "فشل تفسير الحلم")
        self.assertIn('query_id', interpretation, "لم يتم إرجاع معرف الاستعلام")
        self.assertIn('response', interpretation, "لم يتم إرجاع الاستجابة")
        
        print(f"تفسير الحلم: {interpretation['response'][:100]}...")
    
    def test_learning_system(self):
        """اختبار نظام التعلم"""
        # اختبار تفسير حلم باستخدام نظام التعلم
        query = "حلمت أنني أسبح في بحر صافٍ"
        interpretation = self.learning_system.interpret_dream(query)
        
        self.assertIsNotNone(interpretation, "فشل تفسير الحلم باستخدام نظام التعلم")
        
        # اختبار حفظ التقييم
        query_id = interpretation['query_id']
        self.learning_system.save_feedback(query_id, 5, "تفسير ممتاز")
        
        # التحقق من حفظ التقييم
        self.db_manager.connect()
        self.db_manager.cursor.execute("SELECT COUNT(*) FROM user_feedback WHERE query_id = ?", (query_id,))
        count = self.db_manager.cursor.fetchone()[0]
        self.db_manager.disconnect()
        
        self.assertEqual(count, 1, "لم يتم حفظ التقييم")
        
        # اختبار الحصول على إحصائيات التعلم
        stats = self.learning_system.get_learning_stats()
        self.assertIsNotNone(stats, "فشل الحصول على إحصائيات التعلم")
        print(f"إحصائيات التعلم: {stats}")

if __name__ == '__main__':
    unittest.main()
