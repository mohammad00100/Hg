from flask import Flask, request, jsonify, render_template, send_from_directory
import os
import json
import time
from datetime import datetime
from learning_system import DreamLearningSystem

app = Flask(__name__, static_folder='static', template_folder='templates')

# تهيئة نظام التعلم الذاتي
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
CSV_PATH = os.path.join(BASE_DIR, 'data', 'dream.csv')
DB_PATH = os.path.join(BASE_DIR, 'data', 'dreams.db')
MODELS_DIR = os.path.join(BASE_DIR, 'models')

# التأكد من وجود المجلدات اللازمة
os.makedirs(os.path.join(BASE_DIR, 'data'), exist_ok=True)
os.makedirs(MODELS_DIR, exist_ok=True)
os.makedirs(os.path.join(BASE_DIR, 'static'), exist_ok=True)
os.makedirs(os.path.join(BASE_DIR, 'templates'), exist_ok=True)

# تهيئة نظام التعلم
dream_system = DreamLearningSystem(DB_PATH, CSV_PATH, MODELS_DIR)

@app.route('/')
def index():
    """الصفحة الرئيسية"""
    return render_template('index.html')

@app.route('/api/interpret', methods=['POST'])
def interpret_dream():
    """واجهة برمجة التطبيقات لتفسير الأحلام"""
    data = request.json
    
    if not data or 'dream' not in data:
        return jsonify({'error': 'يرجى توفير نص الحلم'}), 400
    
    dream_text = data['dream']
    session_id = data.get('session_id')
    
    # تفسير الحلم
    interpretation = dream_system.interpret_dream(dream_text, session_id)
    
    return jsonify(interpretation)

@app.route('/api/feedback', methods=['POST'])
def save_feedback():
    """واجهة برمجة التطبيقات لحفظ تقييم المستخدم"""
    data = request.json
    
    if not data or 'query_id' not in data or 'rating' not in data:
        return jsonify({'error': 'يرجى توفير معرف الاستعلام والتقييم'}), 400
    
    query_id = data['query_id']
    rating = data['rating']
    notes = data.get('notes')
    
    # حفظ التقييم
    dream_system.save_feedback(query_id, rating, notes)
    
    return jsonify({'success': True})

@app.route('/api/stats', methods=['GET'])
def get_stats():
    """واجهة برمجة التطبيقات للحصول على إحصائيات التعلم"""
    stats = dream_system.get_learning_stats()
    return jsonify(stats)

@app.route('/api/train', methods=['POST'])
def train_models():
    """واجهة برمجة التطبيقات لتدريب النماذج يدويًا"""
    dream_system.train_models()
    return jsonify({'success': True})

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
