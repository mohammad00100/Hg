import sqlite3
import pandas as pd
import os
import json
from datetime import datetime

class DreamDatabase:
    """
    مدير قاعدة بيانات SQLite لنظام تفسير الأحلام المحسن
    يتعامل مع تخزين واسترجاع البيانات وتحديثها
    """
    
    def __init__(self, db_path='dreams.db', csv_path=None):
        """
        تهيئة قاعدة البيانات
        
        المعلمات:
            db_path (str): مسار ملف قاعدة البيانات
            csv_path (str): مسار ملف CSV الأصلي (اختياري)
        """
        self.db_path = db_path
        self.csv_path = csv_path
        self.conn = None
        self.cursor = None
        self.initialize_db()
        
    def connect(self):
        """إنشاء اتصال بقاعدة البيانات"""
        self.conn = sqlite3.connect(self.db_path)
        self.cursor = self.conn.cursor()
        
    def disconnect(self):
        """إغلاق الاتصال بقاعدة البيانات"""
        if self.conn:
            self.conn.close()
            self.conn = None
            self.cursor = None
    
    def initialize_db(self):
        """إنشاء جداول قاعدة البيانات إذا لم تكن موجودة"""
        self.connect()
        
        # جدول التفسيرات الأساسي
        self.cursor.execute('''
        CREATE TABLE IF NOT EXISTS interpretations (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            interpreter TEXT,
            term TEXT,
            interpretation TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
        ''')
        
        # جدول استعلامات المستخدمين
        self.cursor.execute('''
        CREATE TABLE IF NOT EXISTS user_queries (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            query TEXT,
            response TEXT,
            session_id TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
        ''')
        
        # جدول تقييمات المستخدمين
        self.cursor.execute('''
        CREATE TABLE IF NOT EXISTS user_feedback (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            query_id INTEGER,
            rating INTEGER,
            notes TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (query_id) REFERENCES user_queries (id)
        )
        ''')
        
        # جدول كلمات مفتاحية للتفسيرات
        self.cursor.execute('''
        CREATE TABLE IF NOT EXISTS keywords (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            interpretation_id INTEGER,
            keyword TEXT,
            weight REAL DEFAULT 1.0,
            FOREIGN KEY (interpretation_id) REFERENCES interpretations (id)
        )
        ''')
        
        # جدول نماذج التعلم
        self.cursor.execute('''
        CREATE TABLE IF NOT EXISTS ml_models (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            model_name TEXT,
            model_data BLOB,
            version TEXT,
            accuracy REAL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
        ''')
        
        # جدول إحصائيات التعلم
        self.cursor.execute('''
        CREATE TABLE IF NOT EXISTS learning_stats (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            metric_name TEXT,
            metric_value REAL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
        ''')
        
        self.conn.commit()
        
        # استيراد البيانات من CSV إذا كان متاحًا وكانت قاعدة البيانات فارغة
        if self.csv_path and os.path.exists(self.csv_path):
            self.cursor.execute("SELECT COUNT(*) FROM interpretations")
            count = self.cursor.fetchone()[0]
            if count == 0:
                self.import_from_csv()
        
        self.disconnect()
    
    def import_from_csv(self):
        """استيراد البيانات من ملف CSV إلى قاعدة البيانات"""
        try:
            print(f"بدء استيراد البيانات من {self.csv_path}")
            
            # قراءة ملف CSV مباشرة بدون pandas لتجنب مشاكل الترميز
            with open(self.csv_path, 'r', encoding='utf-8') as f:
                lines = f.readlines()
            
            # تجاهل السطر الأول (العناوين)
            if len(lines) > 1:
                header = lines[0].strip().split(',')
                data_lines = lines[1:]
                
                # معالجة كل سطر
                for i, line in enumerate(data_lines):
                    # تقسيم السطر إلى حقول
                    # استخدام تقسيم بسيط بدلاً من CSV parser لتجنب مشاكل التنسيق
                    parts = line.strip().split(',', 2)
                    
                    if len(parts) >= 3:
                        interpreter = parts[0].strip()
                        term = parts[1].strip()
                        interpretation = parts[2].strip()
                        
                        # إدخال البيانات في جدول التفسيرات
                        self.cursor.execute(
                            "INSERT INTO interpretations (interpreter, term, interpretation) VALUES (?, ?, ?)",
                            (interpreter, term, interpretation)
                        )
                        
                        # الحصول على معرف التفسير المدخل
                        interpretation_id = self.cursor.lastrowid
                        
                        # استخراج الكلمات المفتاحية من المصطلح والتفسير
                        term_words = set(term.split())
                        interp_words = set(interpretation.split()[:20])
                        keywords = term_words.union(interp_words)
                        
                        # إدخال الكلمات المفتاحية
                        for keyword in keywords:
                            if len(keyword) > 2:  # تجاهل الكلمات القصيرة جدًا
                                self.cursor.execute(
                                    "INSERT INTO keywords (interpretation_id, keyword) VALUES (?, ?)",
                                    (interpretation_id, keyword)
                                )
                
                self.conn.commit()
                print(f"تم استيراد {len(data_lines)} سجل من ملف CSV")
            else:
                print("ملف CSV فارغ أو يحتوي على العناوين فقط")
        except Exception as e:
            print(f"خطأ أثناء استيراد البيانات من CSV: {e}")
            self.conn.rollback()
    
    def search_interpretations(self, query, limit=5):
        """
        البحث عن تفسيرات بناءً على استعلام المستخدم
        
        المعلمات:
            query (str): استعلام المستخدم
            limit (int): الحد الأقصى لعدد النتائج
            
        العائد:
            list: قائمة بالتفسيرات المطابقة
        """
        self.connect()
        
        # تقسيم الاستعلام إلى كلمات
        query_words = query.split()
        
        if not query_words:
            self.disconnect()
            return []
        
        # إنشاء استعلام SQL للبحث عن التفسيرات المطابقة
        placeholders = ','.join(['?'] * len(query_words))
        sql = f"""
        SELECT i.id, i.interpreter, i.term, i.interpretation, COUNT(k.id) as match_count
        FROM interpretations i
        JOIN keywords k ON i.id = k.interpretation_id
        WHERE k.keyword IN ({placeholders})
        GROUP BY i.id
        ORDER BY match_count DESC
        LIMIT ?
        """
        
        # تنفيذ الاستعلام
        params = query_words + [limit]
        self.cursor.execute(sql, params)
        results = self.cursor.fetchall()
        
        # تحويل النتائج إلى قائمة من القواميس
        interpretations = []
        for row in results:
            interpretations.append({
                'id': row[0],
                'interpreter': row[1],
                'term': row[2],
                'interpretation': row[3],
                'relevance': row[4] / len(query_words)  # حساب مدى الصلة
            })
        
        # إذا لم يتم العثور على نتائج، حاول البحث في جدول التفسيرات مباشرة
        if not interpretations:
            for word in query_words:
                like_pattern = f"%{word}%"
                sql = """
                SELECT id, interpreter, term, interpretation
                FROM interpretations
                WHERE term LIKE ? OR interpretation LIKE ?
                LIMIT ?
                """
                self.cursor.execute(sql, (like_pattern, like_pattern, limit))
                results = self.cursor.fetchall()
                
                for row in results:
                    interpretations.append({
                        'id': row[0],
                        'interpreter': row[1],
                        'term': row[2],
                        'interpretation': row[3],
                        'relevance': 0.5  # قيمة افتراضية للصلة
                    })
                
                if interpretations:
                    break
        
        self.disconnect()
        return interpretations
    
    def save_user_query(self, query, response, session_id=None):
        """
        حفظ استعلام المستخدم والاستجابة
        
        المعلمات:
            query (str): استعلام المستخدم
            response (str): الاستجابة المقدمة
            session_id (str): معرف الجلسة (اختياري)
            
        العائد:
            int: معرف الاستعلام المحفوظ
        """
        self.connect()
        
        # إذا لم يتم توفير معرف جلسة، إنشاء معرف جديد
        if not session_id:
            session_id = f"session_{datetime.now().strftime('%Y%m%d%H%M%S')}"
        
        # حفظ الاستعلام والاستجابة
        self.cursor.execute(
            "INSERT INTO user_queries (query, response, session_id) VALUES (?, ?, ?)",
            (query, response, session_id)
        )
        
        query_id = self.cursor.lastrowid
        self.conn.commit()
        self.disconnect()
        
        return query_id
    
    def save_feedback(self, query_id, rating, notes=None):
        """
        حفظ تقييم المستخدم
        
        المعلمات:
            query_id (int): معرف الاستعلام
            rating (int): التقييم (1-5)
            notes (str): ملاحظات المستخدم (اختياري)
        """
        self.connect()
        
        self.cursor.execute(
            "INSERT INTO user_feedback (query_id, rating, notes) VALUES (?, ?, ?)",
            (query_id, rating, notes)
        )
        
        self.conn.commit()
        self.disconnect()
    
    def get_learning_data(self, limit=1000):
        """
        الحصول على بيانات التعلم (الاستعلامات والتقييمات)
        
        المعلمات:
            limit (int): الحد الأقصى لعدد السجلات
            
        العائد:
            list: قائمة بالبيانات للتعلم
        """
        self.connect()
        
        # الحصول على الاستعلامات مع تقييماتها
        self.cursor.execute("""
        SELECT q.id, q.query, q.response, f.rating
        FROM user_queries q
        JOIN user_feedback f ON q.id = f.query_id
        ORDER BY f.created_at DESC
        LIMIT ?
        """, (limit,))
        
        results = self.cursor.fetchall()
        
        # تحويل النتائج إلى قائمة من القواميس
        learning_data = []
        for row in results:
            learning_data.append({
                'id': row[0],
                'query': row[1],
                'response': row[2],
                'rating': row[3]
            })
        
        self.disconnect()
        return learning_data
    
    def save_model(self, model_name, model_data, version, accuracy):
        """
        حفظ نموذج تعلم آلي
        
        المعلمات:
            model_name (str): اسم النموذج
            model_data (bytes): بيانات النموذج المسلسلة
            version (str): إصدار النموذج
            accuracy (float): دقة النموذج
        """
        self.connect()
        
        self.cursor.execute(
            "INSERT INTO ml_models (model_name, model_data, version, accuracy) VALUES (?, ?, ?, ?)",
            (model_name, model_data, version, accuracy)
        )
        
        self.conn.commit()
        self.disconnect()
    
    def get_latest_model(self, model_name):
        """
        الحصول على أحدث نموذج تعلم آلي
        
        المعلمات:
            model_name (str): اسم النموذج
            
        العائد:
            dict: بيانات النموذج
        """
        self.connect()
        
        self.cursor.execute(
            "SELECT id, model_data, version, accuracy, created_at FROM ml_models WHERE model_name = ? ORDER BY created_at DESC LIMIT 1",
            (model_name,)
        )
        
        result = self.cursor.fetchone()
        
        if result:
            model = {
                'id': result[0],
                'model_data': result[1],
                'version': result[2],
                'accuracy': result[3],
                'created_at': result[4]
            }
        else:
            model = None
        
        self.disconnect()
        return model
    
    def update_learning_stats(self, metric_name, metric_value):
        """
        تحديث إحصائيات التعلم
        
        المعلمات:
            metric_name (str): اسم المقياس
            metric_value (float): قيمة المقياس
        """
        self.connect()
        
        self.cursor.execute(
            "INSERT INTO learning_stats (metric_name, metric_value) VALUES (?, ?)",
            (metric_name, metric_value)
        )
        
        self.conn.commit()
        self.disconnect()
    
    def get_learning_stats(self, metric_name, limit=10):
        """
        الحصول على إحصائيات التعلم
        
        المعلمات:
            metric_name (str): اسم المقياس
            limit (int): الحد الأقصى لعدد السجلات
            
        العائد:
            list: قائمة بالإحصائيات
        """
        self.connect()
        
        self.cursor.execute(
            "SELECT metric_value, created_at FROM learning_stats WHERE metric_name = ? ORDER BY created_at DESC LIMIT ?",
            (metric_name, limit)
        )
        
        results = self.cursor.fetchall()
        
        stats = []
        for row in results:
            stats.append({
                'value': row[0],
                'timestamp': row[1]
            })
        
        self.disconnect()
        return stats
